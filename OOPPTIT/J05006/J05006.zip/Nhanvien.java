package J05006;
import java.util.*;
import java.text.*;
public class Nhanvien {
    private String ma, ten, gioitinh, diachi, masothue;
    private Date ngaysinh, ngayky;
    private static int cnt = 0;
    public Nhanvien(String ten, String gioitinh, String ngaysinh, String diachi, String masothue, String ngayky) throws ParseException {
        cnt++;
        this.ma = String.format("%05d",cnt);
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.diachi = diachi;
        this.masothue = masothue;
        this.ngaysinh = new SimpleDateFormat("dd/MM/yyyy").parse(ngaysinh);
        this.ngayky = new SimpleDateFormat("dd/MM/yyyy").parse(ngayky);
    }

    public String toString(){
        return ma + " " + ten + " " + gioitinh + " " + new SimpleDateFormat("dd/MM/yyyy").format(ngaysinh)
                + " " + diachi + " " + masothue + " " + new SimpleDateFormat("dd/MM/yyyy").format(ngayky);
    }
}
