package TH9;
import java.util.*;
public class SinhVien {
    private String Name;
    private int Correct,Submit;
    public SinhVien(String Name,int Correct,int Submit){
        this.Name = Name;
        this.Correct = Correct;
        this.Submit = Submit;
    }
    public static Comparator<SinhVien> ss(){
        return new Comparator<SinhVien>(){
            public int compare(SinhVien a,SinhVien b){
                if(a.Correct == b.Correct){
                    return Integer.compare(a.Submit,b.Submit);
                }
                return Integer.compare(b.Submit,a.Submit);
            }
        };
    }
    public String toString(){
        return Name + " " + Correct + " " + Submit;
    }
}
