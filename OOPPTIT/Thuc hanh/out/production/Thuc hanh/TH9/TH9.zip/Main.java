package TH9;
import java.util.*;
import java.io.*;
public class Main {
    public static void main(String[] args) throws FileNotFoundException,NumberFormatException{
        File x = new File("LUYENTAP.in");
        Scanner sc = new Scanner(x);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList<SinhVien> res = new ArrayList<>();
        while(t --> 0){
            String name = sc.nextLine();
            if (sc.hasNextLine()) {
                String[] b = sc.nextLine().split(" ");
                int correct = Integer.parseInt(b[0]);
                int submit = Integer.parseInt(b[1]);
                SinhVien a = new SinhVien(name, correct, submit);
                res.add(a);
            }
        }
        Collections.sort(res,SinhVien.ss());
        for(SinhVien s : res){
            System.out.println(s);
        }
    }
}
