package TH8;

import java.util.*;

public class SinhVien {
    private String msv,name,lop,email,sdt;
    public SinhVien(String msv,String name,String lop,String email,String sdt){
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.email = email;
        this.sdt = sdt;
    }
    public static Comparator<SinhVien> ss() {
        return new Comparator<SinhVien>() {
            public int compare(SinhVien a, SinhVien b) {
                if(a.lop.compareTo(b.lop) == 0){
                    return a.msv.compareTo(b.msv);
                }
                return a.lop.compareTo(b.lop);
            }
        };
    }
    public String toString(){
        return msv + " " + name + " " + lop + " " + email + " " + "0"+sdt;
    }
}
