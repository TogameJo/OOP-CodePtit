package TH8;
import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException{
        File x = new File("DANHSACH.in");
        Scanner sc = new Scanner(x);
        ArrayList<SinhVien> res = new ArrayList<>();
        while(sc.hasNextLine()){
            String msv = sc.nextLine();
            String name = sc.nextLine();
            String lop = sc.nextLine();
            String email = sc.nextLine();
            String sdt = sc.nextLine();
            SinhVien a = new SinhVien(msv,name,lop,email,sdt);
            res.add(a);
        }
        Collections.sort(res,SinhVien.ss());
        for(SinhVien s : res){
            System.out.println(s);
        }
    }
}
