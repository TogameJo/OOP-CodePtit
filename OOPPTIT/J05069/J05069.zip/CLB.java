package J05069;

public class CLB {
    private String code,name;
    private int gv;

    public CLB(String code, String name, int gv) {
        this.code = code;
        this.name = name;
        this.gv = gv;
    }

    public String getCode() {
        return code;
    }

    public int getGv() {
        return gv;
    }

    public String getName() {
        return name;
    }
}
