/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codejava.GiangVien;
import java.util.*;
/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<GV> dsgv = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            String id = "GV" + String.format("%02d",i);
            String name = sc.nextLine();
            String bm = sc.nextLine();
            dsgv.add(new GV(id, name, bm));
        }
        Collections.sort(dsgv);
        for(GV a : dsgv){
            System.out.println(a);
        }
    }
}

//3
//Nguyen Manh Son
//Cong nghe phan mem
//Vu Hoai Nam
//Khoa hoc may tinh
//Dang Minh Tuan
//An toan thong tin