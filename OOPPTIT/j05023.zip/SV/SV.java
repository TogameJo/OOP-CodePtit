/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codejava.SV;

/**
 *
 * @author ADMIN
 */
public class SV implements Comparable<SV>{
    private String id, name, lop, em;

    public SV(String id, String name, String lop, String em) {
        this.id = id;
        this.name = name;
        this.lop = lop;
        this.em = em;
    }

    public String getLop() {
        return lop;
    }
    
    public int compareTo(SV o) {
        return this.id.compareTo(o.id);
    }
    
    @Override
    public String toString() {
        return id + " " + name + " " + lop + " " + em + " ";
    }
}
