/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codejava.GiangVien;

import java.util.*;
import java.util.StringTokenizer;

/**
 *
 * @author ADMIN
 */
public class GV implements Comparable<GV>{
    private String id, name, bm;

    public GV(String id, String name, String bm) {
        this.id = id;
        this.name = name;
        this.bm = bm;
    }
    
    public String mabm(){
        String s = this.bm.toUpperCase();
        StringTokenizer tk = new StringTokenizer(s);
        ArrayList<String> w = new ArrayList<>();
        while (tk.hasMoreTokens()){
            w.add(tk.nextToken());
        }
        StringBuilder res = new StringBuilder();
        for(String a : w){
            res.append(a.charAt(0));
        }
        return this.bm = res.toString();
    }

    public String getBm() {
        return bm;
    }
    
    public String ten(){
        String s = this.name;
        StringTokenizer tk = new StringTokenizer(s);
        ArrayList<String> w = new ArrayList<>();
        while(tk.hasMoreTokens()){
            w.add(tk.nextToken());
        }
        return w.get(w.size()-1);
    }
    
    @Override
    public int compareTo(GV o) {
//        if(this.ten().equals(o.ten())) return this.id.compareTo(o.id);
        return this.ten().compareTo(o.ten());
    }

    @Override
    public String toString() {
        mabm();
        return id + " " + name + " " + bm;
    }
    
}
