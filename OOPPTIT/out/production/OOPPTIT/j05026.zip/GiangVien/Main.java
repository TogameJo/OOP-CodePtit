/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codejava.GiangVien;
import java.util.*;
/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<GV> dsgv = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            String id = "GV" + String.format("%02d",i);
            String name = sc.nextLine();
            String bm = sc.nextLine();
            dsgv.add(new GV(id, name, bm));
        }
        //Collections.sort(dsgv);
        int q = sc.nextInt();
        sc.nextLine();
        for(int i = 0; i < q; i++){
            String s = sc.nextLine();
            String s1 = s;
            s = s.toUpperCase();
            StringTokenizer tk = new StringTokenizer(s);
            ArrayList<String> w = new ArrayList<>();
            while (tk.hasMoreTokens()){
                w.add(tk.nextToken());
            }
            StringBuilder res = new StringBuilder();
            for(String a : w){
                res.append(a.charAt(0));
            }
            s = res.toString();
            
            System.out.println("DANH SACH GIANG VIEN BO MON " + s + ":");
            for(GV a : dsgv){
                if(a.getBm().equals(s1)) System.out.println(a);
            }
        }
    }
}

//3
//Nguyen Manh Son
//Cong nghe phan mem
//Vu Hoai Nam
//Khoa hoc may inh
//Dang Minh Tuan
//An toan thong tin
//1
//Cong nghe phan mem