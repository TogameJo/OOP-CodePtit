package J06007;

import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int mmh = sc.nextInt();
        sc.nextLine();
        ArrayList<MonHoc> mh = new ArrayList<>();
        for(int i = 0;i < mmh;i++){
            String id = sc.next();
            String name = sc.nextLine().trim();
            mh.add(new MonHoc(id,name));
        }

        int mgv = sc.nextInt();
        sc.nextLine();
        ArrayList<GiangVien> gv = new ArrayList<>();
        for(int i = 0;i < mgv;i++){
            String idgv = sc.next();
            String namegv = sc.nextLine().trim();
            gv.add(new GiangVien(idgv,namegv));
        }

        int mtg = sc.nextInt();
        sc.nextLine();
        ArrayList<ThoiGian> tg = new ArrayList<>();
        for(int i = 0;i < mtg;i++){
            String idgv = sc.next();
            String idmh = sc.next();
            double time = sc.nextDouble();
            sc.nextLine();
            GiangVien gvien = null;
            for(GiangVien g :gv){
                if(g.getId().equals(idgv)){
                    gvien = g;
                }
            }

            tg.add(new ThoiGian(gvien,time));
        }

        for(ThoiGian res : tg){
            System.out.println(res);
        }
    }
}
/*
2
INT1155 Tin hoc co so 2
INT1306 Cau truc du lieu va giai thuat
2
GV01 Nguyen Van An
GV02 Hoang Binh Minh
2
GV01 INT1155 113.2
GV02 INT1306 126.72
 */